//
//  TestViewController.h
//  testCordova
//
//  Created by Administrator on 16/9/22.
//
//

#import <UIKit/UIKit.h>

@interface TestViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *labTitle;
@property (strong, nonatomic)  NSString *url;
@end
